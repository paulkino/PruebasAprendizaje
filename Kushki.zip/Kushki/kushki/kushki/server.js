const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const axios = require('axios');

// Configurar body-parser
app.use(bodyParser.urlencoded({ extended: false }));

// Ruta para servir la página estática
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/confirm', function (req, res) {
    // Tu código aquí
    let kushkiToken = req.body.kushkiToken;
    let bodyRequest = {
        "token": kushkiToken,
        "planName": "KINO SUBSCRIPTION",
        "periodicity": "monthly",
        "contactDetails": {
            "documentType": "CC",
            "documentNumber": "1265734234",
            "email": "kinaPower@outlook.com",
            "firstName": "Kina",
            "lastName": "Quinaucho",
            "phoneNumber": "+652374234345"
        },
        "amount": {
            "subtotalIva": 0,
            "subtotalIva0": 107.00,
            "ice": 0,
            "iva": 0,
            "currency": "USD"
        },
        "startDate": "2021-11-05",
        "metadata": {}
    };
    axios({
        method: 'post',
        url: 'https://api-uat.kushkipagos.com/subscriptions/v1/card',
        headers: {
            'content-type': 'application/json',
            'private-merchant-id': '7843cac5f91f4f19bb901d8a35b0082f'
        },
        data: bodyRequest
    })
    .then(function (response) {
        res.send(`Datos recibidos: ${response.data.subscriptionId}`);
    })
    .catch(function (error) {
        res.send(`Error: ${error}`);
    });
});

app.listen(8080, () => {
    console.log('App listening on port 8080');
});
